<?php
if ( ! defined( 'ABSPATH' ) ) exit;

return [
	'title'              => esc_html__('Adaptive Background', 'bdthemes-prime-slider' ),
	'required'           => true,
	'default_activation' => true,
    'has_script'		 => true,
];

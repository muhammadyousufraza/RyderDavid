=== Prime Slider - Addons For Elementor (Revolution of a slider, Hero Slider, Ecommerce Slider) ===
Contributors: bdthemes, selimmw, mohammaadfarid, bdkoder, abutalib, maudud, muhammadasik
Donate link: http://bdthemes.com/
Tags: wordpress slider, elementor addons, slider, image slider, video slider
Requires at least: 5.0.0
Tested up to: 6.4.3
Requires PHP: 7.4.0
Stable tag: 3.13.3
License: GPL3
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Elementor requires at least: 3.0.0
Elementor tested up to: 3.20.2

Best Addon for Elementor WordPress Plugin with 50+ Awesome slider design that you can use your modern website with elementor website builder.
